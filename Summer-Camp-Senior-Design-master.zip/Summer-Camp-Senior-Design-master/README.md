# Summer-Camp-Senior-Design
ME437-SP-2017

This repository allows new robot(for now) RPi's to be configured in one easy step by simply pulling from this repository (in theory)
